<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="_Emulation Programming_" />
<meta name="keywords" content="_Emulation,Chip8,Gameboy,NES,SNES,Genesis,Master,System,Mega,Drive_" />
<meta name="author" content="CodeSlinger /" />
<link rel="stylesheet" type="text/css" href="css.css" media="screen,projection" title="CodeSlinger (screen)" />
<link rel="stylesheet" type="text/css" href="print.css" media="print" />
<title>codeslinger.co.uk</title>
</head>

<body>
<div>
<br><br>
</div>

<div id="container">
<div id="logo">
<h1><a href="index.html">codeslinger.co.uk</a></h1>
</div>

<div id="navitabs">
<h2 class="hide">Site menu:</h2>
<a class="activenavitab" href="index.html">Home</a><span class="hide"> | </span>
<a class="navitab" href="pages/basics.html">Basics</a><span class="hide"> | </span>
<a class="navitab" href="pages/projects/zuko.html">Zuko</a><span class="hide"> | </span>
<a class="navitab" href="pages/projects/megadrive.html">Mega Drive/Genesis</a><span class="hide"> | </span>
<a class="navitab" href="pages/projects/mastersystem.html">Master System</a><span class="hide"> | </span>
<a class="navitab" href="pages/projects/gameboy.html">Gameboy</a><span class="hide"> | </span>
<a class="navitab" href="pages/projects/chip8.html">Chip8</a><span class="hide"> | </span>
<a class="navitab" href="pages/blog/index.html">Blog</a><span class="hide"> | </span>
</div>
	
<div id="desc">
<h2>Welcome to codeslinger.co.uk</h2>
<p>Dedicated to the art of emulation programming</p>

</div>

<div id="main">
<h3><b>About:</b></h3>
<p> This website is intended to help newcomers to emulation programming understand the logic behind making an emulator. As you can see from my development blog I am no emulation expert but hopefully beginners should find a lot of useful material here. The idea of this website is to break down the system I am working on and decide the best way to emulate each part. My completed emulators also have their own section of the website so you can look back at the troubles I had emulating the system and how I succeeded. Although I try to teach programming logic this is not a general programming site, so you will need to know at least one programming language. All examples on this site including the source code are in C++. Im not gonna post the source code for all my emulators just some. </p>

<p class="block"><strong>Please note:</strong> I do not host copyrighted Roms on this website and I never will, so please dont ask. </p>

<h3><b>Update: 17th March 2009</b></h3>
<p>
Well after a fem months break I am back and ready to continue with my emulation development. My SMS tutorials are complete and can be found by navigating the top of this page. I'll probably optimize my gameboy emulator and add sound next before starting a mega drive emulator.
</p>

<h3><b>Update: 18th December 2008</b></h3>
<p>

My Sega Master System Emulator has approximately 95% compatibility including sound emulation. Over the next few days I shall write the tutorials for SMS emulation and shall upload them to this site. Check back in a few days.

</p>

<h3><b>Update: 9th August 2008</b></h3>
<p>

I have finally finished the gameboy tutorial section of the site. Use the navigation bar at the top to go to it. Next I will be coding a Sega Master System emulator.

</p>

<h3><b>Update: 29th July 2008</b></h3>
<p>

My gameboy emulator has approximately 95% compatibility which is enough for me to create the Gameboy howto section. I shall start writing this today and hopefully over the next few weeks I'll have this section of the site complete. However I have not emulated sound yet.

</p> 

<h3><b>Update: 1st July 2008</b></h3>
<p>

Please bare with me while I get all features of this site up and running. I'll start with getting my Chip8 emulator tutorials up and then I'll start to upload my Gameboy resources which is the system I am currently emulating.

</p> 

</div>

<div id="sidebar">
<h3>Links:</h3>
<p>

Emulation links will be up when the rest of the site is up and running

</p>

<p>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>
<a class="sidelink" href="">Links Coming Soon</a><span class="hide"> | </span>

</p>


</div>
    
<div id="footer">
Copyright &copy; 2008 codeslinger.co.uk</div>

</div>
</body>
</html>